package com.cg.ibs.rm.ui;

public enum Status {
		APPROVED, DECLINED, PENDING
}
