package com.cg.ibs.rm.ui;

public enum Bank_Admin {
	 	VIEWREQUESTS, EXIT
}
