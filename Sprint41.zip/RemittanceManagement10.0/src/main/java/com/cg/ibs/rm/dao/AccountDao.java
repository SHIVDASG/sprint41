package com.cg.ibs.rm.dao;

import java.math.BigInteger;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.cg.ibs.rm.bean.AccountBean;
import com.cg.ibs.rm.util.JpaUtil;

public class AccountDao {
	EntityManager manager = JpaUtil.getEntityManger();

	public Set<AccountBean> getAccounts(BigInteger uci) {
		TypedQuery<AccountBean> query = manager
				.createQuery("SELECT a FROM AcccountBean a INNER JOIN AccountHoldingBean ac on ac.customer.uci = ?1", AccountBean.class);
		query.setParameter(1, uci);
		return new HashSet<>(query.getResultList());
	}
}
