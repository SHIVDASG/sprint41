package com.cg.ibs.rm.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.math.BigInteger;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import com.cg.ibs.rm.bean.Beneficiary;
import com.cg.ibs.rm.bean.CreditCard;
import com.cg.ibs.rm.exception.IBSExceptions;
import com.cg.ibs.rm.ui.Type;

class BankRepresentativeServiceImplTest {
	Bank_AdminService object = new Bank_AdminServiceImpl();
	BeneficiaryAccountServiceImpl object1 = new BeneficiaryAccountServiceImpl();
	Beneficiary beneficiary = new Beneficiary();

	@Test
	public void testShowRequests1() {
		try {
			assertEquals(1, object.showRequests().size());
		} catch (IBSExceptions exception) {
			Throwable throwable = assertThrows(IBSExceptions.class, () -> {
				throw new IBSExceptions(exception.getMessage());
			});
			assertSame("Card not added", throwable.getMessage());
		}
	}

	@Test
	public void testShowRequests2() {
		try {
			assertNotNull(object.showRequests());
		} catch (IBSExceptions exception) {
			Throwable throwable = assertThrows(IBSExceptions.class, () -> {
				throw new IBSExceptions(exception.getMessage());
			});
			assertSame("Card not added", throwable.getMessage());
		}
	}

	@Test
	public void testShowUnapprovedCreditCards1() {
		try {
			assertEquals(3, object.showUnapprovedCreditCards("5555111151513301").size());
		} catch (IBSExceptions exception) {
			Throwable throwable = assertThrows(IBSExceptions.class, () -> {
				throw new IBSExceptions(exception.getMessage());
			});
			assertSame("Card not added", throwable.getMessage());
		}
	}

	@Test
	public void testShowUnapprovedCreditCards2() {
		try {
			assertNotNull(object.showUnapprovedCreditCards("5555111151513301"));
		} catch (IBSExceptions exception) {
			Throwable throwable = assertThrows(IBSExceptions.class, () -> {
				throw new IBSExceptions(exception.getMessage());
			});
			assertSame("Card not added", throwable.getMessage());
		}
	}

	@Test
	public void testShowUnapprovedBeneficiaries1() {
		try {
			assertEquals(1, object.showUnapprovedBeneficiaries("5555111151513301").size());
		} catch (IBSExceptions exception) {
			Throwable throwable = assertThrows(IBSExceptions.class, () -> {
				throw new IBSExceptions(exception.getMessage());
			});
			assertSame("Card not added", throwable.getMessage());
		}
	}

	@Test
	public void testShowUnapprovedBeneficiaries2() {
		try {
			assertNotNull(object.showUnapprovedCreditCards("5555111151513301"));
		} catch (IBSExceptions exception) {
			Throwable throwable = assertThrows(IBSExceptions.class, () -> {
				throw new IBSExceptions(exception.getMessage());
			});
			assertSame("Card not added", throwable.getMessage());
		}
	}

	@Disabled
	@Test
	public void testSaveCreditCardDetails1() {
		CreditCard card = new CreditCard();
		card.setcreditCardNumber(new BigInteger("1234567890129999"));
		card.setcreditDateOfExpiry("12/2020");
		card.setnameOnCreditCard("saimasree");
		try {
			object.saveCreditCardDetails("5555111151513301", card);
		} catch (IBSExceptions exception) {
			Throwable throwable = assertThrows(IBSExceptions.class, () -> {
				throw new IBSExceptions(exception.getMessage());
			});
			assertSame("Card not added", throwable.getMessage());
		}
	}

	@Test
	public void testSaveBeneficiaryDetails1() {
		beneficiary.setAccountNumber(new BigInteger("12345678901"));
		beneficiary.setAccountName("Ayush Handsome");
		beneficiary.setBankName("SBSC");
		beneficiary.setIfscCode("SBSC5623487");
		beneficiary.setType(Type.OTHERSINOTHERS);
		try {
			object.saveBeneficiaryDetails("5555111151513301", beneficiary);
		
		assertEquals(2, object1.showBeneficiaryAccount("5555111151513301").size());
		}catch (IBSExceptions exception) {
			Throwable throwable = assertThrows(IBSExceptions.class, () -> {
				throw new IBSExceptions(exception.getMessage());
			});
			assertSame("Internal Error! Try Again.", throwable.getMessage());
		}
	}

}
